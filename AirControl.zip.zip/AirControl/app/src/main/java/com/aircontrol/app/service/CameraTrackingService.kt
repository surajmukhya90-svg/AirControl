package com.aircontrol.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.aircontrol.app.AirControlApp
import com.aircontrol.app.domain.OneEuroFilter
import com.aircontrol.app.domain.VisualCursorState
import com.aircontrol.app.tracking.HandTrackingAnalyzer
import com.aircontrol.app.ui.MainActivity
import java.util.concurrent.Executors
import kotlin.math.hypot

class CameraTrackingService : Service(), LifecycleOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private var overlayManager: CursorOverlayManager? = null
    private var analyzer: HandTrackingAnalyzer? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val filterX = OneEuroFilter(minCutoff = 0.8, beta = 0.005)
    private val filterY = OneEuroFilter(minCutoff = 0.8, beta = 0.005)

    private var lastHandSeenTime = 0L
    private var isClickTriggered = false
    private var lastTapTime = 0L
    private var lastSwipeTime = 0L

    private var prevIndexY = -1f
    private var prevSwipeSampleTime = 0L

    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        var isServiceRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        overlayManager = CursorOverlayManager(this)
        overlayManager?.show()
        isServiceRunning = true

        startAutoHomeLoop()
    }

    private fun startAutoHomeLoop() {
        val metrics = resources.displayMetrics
        val homeX = metrics.widthPixels / 2f
        val homeY = metrics.heightPixels * 0.85f

        mainHandler.post(object : Runnable {
            override fun run() {
                if (!isServiceRunning) return
                val now = SystemClock.uptimeMillis()
                if (now - lastHandSeenTime > 750L) {
                    overlayManager?.updatePosition(homeX, homeY)
                }
                mainHandler.postDelayed(this, 30L)
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification()
        startForeground(101, notification)
        startCameraAnalysis()
        return START_STICKY
    }

    private fun startCameraAnalysis() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val metrics = resources.displayMetrics
                val screenWidth = metrics.widthPixels.toFloat()
                val screenHeight = metrics.heightPixels.toFloat()

                analyzer = HandTrackingAnalyzer(
                    context = this,
                    onResult = { result, timestamp ->
                        val landmarks = result.landmarks()
                        if (!landmarks.isNullOrEmpty() && landmarks[0].size > 20) {
                            lastHandSeenTime = timestamp
                            val hand = landmarks[0]

                            val wrist = hand[0]
                            val thumbTip = hand[4]
                            val indexTip = hand[8]
                            val middleTip = hand[12]
                            val ringTip = hand[16]

                            val rawScreenX = (indexTip.x() * screenWidth).coerceIn(0f, screenWidth)
                            val rawScreenY = (indexTip.y() * screenHeight).coerceIn(0f, screenHeight)

                            val smoothX = filterX.filter(rawScreenX.toDouble(), timestamp).toFloat()
                            val smoothY = filterY.filter(rawScreenY.toDouble(), timestamp).toFloat()

                            overlayManager?.updatePosition(smoothX, smoothY)

                            val pinchDist = hypot((thumbTip.x() - indexTip.x()).toDouble(), (thumbTip.y() - indexTip.y()).toDouble()).toFloat()
                            val indexToWrist = hypot((indexTip.x() - wrist.x()).toDouble(), (indexTip.y() - wrist.y()).toDouble()).toFloat()
                            val middleToWrist = hypot((middleTip.x() - wrist.x()).toDouble(), (middleTip.y() - wrist.y()).toDouble()).toFloat()
                            val ringToWrist = hypot((ringTip.x() - wrist.x()).toDouble(), (ringTip.y() - wrist.y()).toDouble()).toFloat()

                            val isPinch = pinchDist < 0.085f
                            val isFist = indexToWrist < 0.28f && middleToWrist < 0.28f && ringToWrist < 0.28f

                            if (isPinch || isFist) {
                                overlayManager?.updateState(VisualCursorState.PINCHED)
                                if (!isClickTriggered && (timestamp - lastTapTime > 400L)) {
                                    isClickTriggered = true
                                    lastTapTime = timestamp
                                    AirAccessibilityService.instance?.performTap(smoothX, smoothY)
                                }
                            } else {
                                isClickTriggered = false
                                overlayManager?.updateState(VisualCursorState.NORMAL)
                            }

                            if (timestamp - prevSwipeSampleTime > 160L) {
                                if (prevIndexY > 0f && (timestamp - lastSwipeTime > 700L)) {
                                    val deltaY = indexTip.y() - prevIndexY
                                    if (deltaY < -0.16f) {
                                        lastSwipeTime = timestamp
                                        overlayManager?.updateState(VisualCursorState.SCROLLING)
                                        AirAccessibilityService.instance?.performReelNext(screenWidth, screenHeight)
                                    } else if (deltaY > 0.16f) {
                                        lastSwipeTime = timestamp
                                        overlayManager?.updateState(VisualCursorState.SCROLLING)
                                        AirAccessibilityService.instance?.performReelPrev(screenWidth, screenHeight)
                                    }
                                }
                                prevIndexY = indexTip.y()
                                prevSwipeSampleTime = timestamp
                            }
                        }
                    },
                    onError = { }
                )

                val analysisUseCase = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, analyzer!!)
                    }

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase)
            } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, AirControlApp.CHANNEL_ID)
            .setContentTitle("AirControl is Active")
            .setContentText("Pinch/Fist to tap, Flick up/down for Reels")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        analyzer?.close()
        cameraExecutor.shutdown()
        overlayManager?.hide()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}