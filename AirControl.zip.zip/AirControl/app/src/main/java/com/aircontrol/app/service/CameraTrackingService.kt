package com.aircontrol.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.aircontrol.app.AirControlApp
import com.aircontrol.app.domain.GestureAction
import com.aircontrol.app.domain.GestureStateMachine
import com.aircontrol.app.domain.OneEuroFilter
import com.aircontrol.app.tracking.HandTrackingAnalyzer
import com.aircontrol.app.ui.MainActivity
import java.util.concurrent.Executors

class CameraTrackingService : Service(), LifecycleOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private var overlayManager: CursorOverlayManager? = null
    private var analyzer: HandTrackingAnalyzer? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private val filterX = OneEuroFilter()
    private val filterY = OneEuroFilter()
    private val stateMachine = GestureStateMachine()

    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        var isServiceRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        overlayManager = CursorOverlayManager(this)
        overlayManager?.show()
        isServiceRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createNotification()
        startForeground(101, notification)
        startCameraAnalysis()
        return START_STICKY
    }

    private fun startCameraAnalysis() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val metrics = resources.displayMetrics
            val screenWidth = metrics.widthPixels.toFloat()
            val screenHeight = metrics.heightPixels.toFloat()

            analyzer = HandTrackingAnalyzer(
                context = this,
                onResult = { result, timestamp ->
                    val landmarks = result.landmarks()
                    if (!landmarks.isNullOrEmpty() && landmarks[0].size > 8) {
                        val hand = landmarks[0]
                        val indexX = hand[8].x()
                        val indexY = hand[8].y()
                        val thumbX = hand[4].x()
                        val thumbY = hand[4].y()
                        val middleY = hand[12].y()

                        val rawScreenX = (indexX * screenWidth * 1.5f).coerceIn(0f, screenWidth)
                        val rawScreenY = (indexY * screenHeight * 1.5f).coerceIn(0f, screenHeight)

                        val smoothX = filterX.filter(rawScreenX.toDouble(), timestamp).toFloat()
                        val smoothY = filterY.filter(rawScreenY.toDouble(), timestamp).toFloat()

                        overlayManager?.updatePosition(smoothX, smoothY)

                        stateMachine.processFrame(
                            thumbTipX = thumbX,
                            thumbTipY = thumbY,
                            indexTipX = indexX,
                            indexTipY = indexY,
                            middleTipY = middleY,
                            screenX = smoothX,
                            screenY = smoothY,
                            currentTimeMs = timestamp,
                            onAction = { action ->
                                handleGestureAction(action)
                            },
                            onStateChange = { cursorState ->
                                overlayManager?.updateState(cursorState)
                            }
                        )
                    }
                },
                onError = { }
            )

            val analysisUseCase = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, analyzer!!)
                }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase)
            } catch (_: Exception) {}

        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleGestureAction(action: GestureAction) {
        val accessibility = AirAccessibilityService.instance ?: return
        when (action) {
            is GestureAction.Click -> accessibility.performTap(action.x, action.y)
            is GestureAction.LongPress -> accessibility.performLongPress(action.x, action.y)
            is GestureAction.Scroll -> accessibility.performScroll(action.startX, action.startY, action.deltaY)
            is GestureAction.Back -> accessibility.performBack()
            is GestureAction.Home -> accessibility.performHome()
            is GestureAction.Move, is GestureAction.Drag -> {}
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, AirControlApp.CHANNEL_ID)
            .setContentTitle("AirControl is Active")
            .setContentText("Hand tracking & air gestures are live")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        analyzer?.close()
        cameraExecutor.shutdown()
        overlayManager?.hide()
        stateMachine.reset()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}