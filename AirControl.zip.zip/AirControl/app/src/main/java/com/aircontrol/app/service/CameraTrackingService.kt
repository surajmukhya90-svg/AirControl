package com.aircontrol.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.aircontrol.app.AirControlApp
import com.aircontrol.app.domain.OneEuroFilter
import com.aircontrol.app.domain.VisualCursorState
import com.aircontrol.app.tracking.HandTrackingAnalyzer
import com.aircontrol.app.ui.MainActivity
import java.util.concurrent.Executors
import kotlin.math.hypot

class CameraTrackingService : Service(), LifecycleOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private var overlayManager: CursorOverlayManager? = null
    private var analyzer: HandTrackingAnalyzer? = null
    private var cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Calibrated smooth sensitivity filters
    private val filterX = OneEuroFilter(minCutoff = 0.6, beta = 0.003)
    private val filterY = OneEuroFilter(minCutoff = 0.6, beta = 0.003)

    private var lastHandSeenTime = 0L
    private var isClickTriggered = false
    private var lastTapTime = 0L
    private var lastSwipeTime = 0L
    private var prevIndexY = -1f
    private var prevSwipeSampleTime = 0L

    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        var isServiceRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        try {
            lifecycleRegistry.currentState = Lifecycle.State.CREATED
            lifecycleRegistry.currentState = Lifecycle.State.STARTED
            lifecycleRegistry.currentState = Lifecycle.State.RESUMED

            overlayManager = CursorOverlayManager(this)
            overlayManager?.show()
            isServiceRunning = true

            startAutoHomeLoop()
        } catch (_: Exception) {}
    }

    // Auto-Home: Haath hat te hi mouse screen ke niche (apne ghar) dock ho jaye
    private fun startAutoHomeLoop() {
        val metrics = resources.displayMetrics
        val homeX = metrics.widthPixels / 2f
        val homeY = metrics.heightPixels * 0.88f

        mainHandler.post(object : Runnable {
            override fun run() {
                if (!isServiceRunning) return
                try {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastHandSeenTime > 600L) {
                        overlayManager?.returnToHome(homeX, homeY)
                    }
                } catch (_: Exception) {}
                mainHandler.postDelayed(this, 30L)
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = createNotification()
            startForeground(101, notification)
            startCameraAnalysis()
        } catch (_: Exception) {}
        return START_STICKY
    }

    private fun startCameraAnalysis() {
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val metrics = resources.displayMetrics
                    val screenWidth = metrics.widthPixels.toFloat()
                    val screenHeight = metrics.heightPixels.toFloat()

                    analyzer = HandTrackingAnalyzer(
                        context = this,
                        onResult = { result, timestamp ->
                            try {
                                val landmarks = result.landmarks()
                                if (!landmarks.isNullOrEmpty() && landmarks[0].size > 20) {
                                    lastHandSeenTime = timestamp
                                    val hand = landmarks[0]

                                    val wrist = hand[0]
                                    val thumbTip = hand[4]
                                    val indexTip = hand[8]
                                    val middleTip = hand[12]
                                    val ringTip = hand[16]

                                    // 1. Slow, Steady & Controlled Mouse (Bhagega nahi)
                                    val rawScreenX = (indexTip.x() * screenWidth).coerceIn(0f, screenWidth)
                                    val rawScreenY = (indexTip.y() * screenHeight).coerceIn(0f, screenHeight)

                                    val smoothX = filterX.filter(rawScreenX.toDouble(), timestamp).toFloat()
                                    val smoothY = filterY.filter(rawScreenY.toDouble(), timestamp).toFloat()

                                    overlayManager?.updatePosition(smoothX, smoothY)

                                    // 2. Click: Mutthi (Fist) band karna ya Pinch karna
                                    val pinchDist = hypot((thumbTip.x() - indexTip.x()).toDouble(), (thumbTip.y() - indexTip.y()).toDouble()).toFloat()
                                    val indexToWrist = hypot((indexTip.x() - wrist.x()).toDouble(), (indexTip.y() - wrist.y()).toDouble()).toFloat()
                                    val middleToWrist = hypot((middleTip.x() - wrist.x()).toDouble(), (middleTip.y() - wrist.y()).toDouble()).toFloat()
                                    val ringToWrist = hypot((ringTip.x() - wrist.x()).toDouble(), (ringTip.y() - wrist.y()).toDouble()).toFloat()

                                    val isPinch = pinchDist < 0.085f
                                    val isFist = indexToWrist < 0.28f && middleToWrist < 0.28f && ringToWrist < 0.28f

                                    if (isPinch || isFist) {
                                        overlayManager?.updateState(VisualCursorState.PINCHED)
                                        if (!isClickTriggered && (timestamp - lastTapTime > 400L)) {
                                            isClickTriggered = true
                                            lastTapTime = timestamp
                                            AirAccessibilityService.instance?.performTap(smoothX, smoothY)
                                        }
                                    } else {
                                        isClickTriggered = false
                                        overlayManager?.updateState(VisualCursorState.NORMAL)
                                    }

                                    // 3. Reels Swipe (Ungli upar = Next Reel, niche = Previous Reel)
                                    if (timestamp - prevSwipeSampleTime > 150L) {
                                        if (prevIndexY > 0f && (timestamp - lastSwipeTime > 750L)) {
                                            val deltaY = indexTip.y() - prevIndexY
                                            if (deltaY < -0.15f) {
                                                lastSwipeTime = timestamp
                                                overlayManager?.updateState(VisualCursorState.SCROLLING)
                                                AirAccessibilityService.instance?.performReelNext(screenWidth, screenHeight)
                                            } else if (deltaY > 0.15f) {
                                                lastSwipeTime = timestamp
                                                overlayManager?.updateState(VisualCursorState.SCROLLING)
                                                AirAccessibilityService.instance?.performReelPrev(screenWidth, screenHeight)
                                            }
                                        }
                                        prevIndexY = indexTip.y()
                                        prevSwipeSampleTime = timestamp
                                    }
                                }
                            } catch (_: Exception) {}
                        },
                        onError = { }
                    )

                    val analysisUseCase = ImageAnalysis.Builder()
                        .setTargetResolution(Size(480, 640))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also {
                            it.setAnalyzer(cameraExecutor, analyzer!!)
                        }

                    val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase)
                } catch (_: Exception) {}
            }, ContextCompat.getMainExecutor(this))
        } catch (_: Exception) {}
    }

    private fun createNotification(): Notification {
        val channelId = "aircontrol_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AirControl Running", NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AirControl Active")
            .setContentText("Hand gestures & air mouse live")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        try {
            lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
            analyzer?.close()
            cameraExecutor.shutdown()
            overlayManager?.hide()
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
}