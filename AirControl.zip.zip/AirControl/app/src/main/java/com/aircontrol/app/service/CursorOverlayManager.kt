package com.aircontrol.app.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.aircontrol.app.domain.VisualCursorState

class CursorOverlayManager(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var cursorView: CursorView? = null
    private var isAttached = false

    private val layoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 500
        y = 1000
    }

    fun show() {
        if (!isAttached) {
            cursorView = CursorView(context)
            windowManager.addView(cursorView, layoutParams)
            isAttached = true
        }
    }

    fun updatePosition(x: Float, y: Float) {
        if (!isAttached || cursorView == null) return
        layoutParams.x = x.toInt()
        layoutParams.y = y.toInt()
        windowManager.updateViewLayout(cursorView, layoutParams)
    }

    fun updateState(state: VisualCursorState) {
        cursorView?.setState(state)
    }

    fun hide() {
        if (isAttached && cursorView != null) {
            windowManager.removeView(cursorView)
            cursorView = null
            isAttached = false
        }
    }

    private class CursorView(context: Context) : View(context) {
        private var currentState = VisualCursorState.NORMAL
        private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#4285F4")
        }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 5f
            color = Color.WHITE
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            setMeasuredDimension(80, 80)
        }

        fun setState(state: VisualCursorState) {
            this.currentState = state
            when (state) {
                VisualCursorState.NORMAL -> outerPaint.color = Color.parseColor("#4285F4")
                VisualCursorState.PINCHED -> outerPaint.color = Color.parseColor("#EA4335")
                VisualCursorState.LONG_PRESS -> outerPaint.color = Color.parseColor("#FBBC04")
                VisualCursorState.SCROLLING -> outerPaint.color = Color.parseColor("#34A853")
                else -> outerPaint.color = Color.GRAY
            }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val radius = 22f

            canvas.drawCircle(cx, cy, radius, outerPaint)
            canvas.drawCircle(cx, cy, radius, ringPaint)
        }
    }
}