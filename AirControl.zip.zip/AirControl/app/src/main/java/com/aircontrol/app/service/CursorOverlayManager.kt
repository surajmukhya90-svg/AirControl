package com.aircontrol.app.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.aircontrol.app.domain.VisualCursorState

class CursorOverlayManager(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var cursorView: CursorView? = null
    private var isAttached = false

    private val layoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 500
        y = 1200
    }

    fun show() {
        mainHandler.post {
            if (!isAttached) {
                try {
                    cursorView = CursorView(context)
                    windowManager.addView(cursorView, layoutParams)
                    isAttached = true
                } catch (_: Exception) {}
            }
        }
    }

    fun updatePosition(x: Float, y: Float) {
        mainHandler.post {
            if (!isAttached || cursorView == null) return@post
            layoutParams.x = x.toInt()
            layoutParams.y = y.toInt()
            try {
                windowManager.updateViewLayout(cursorView, layoutParams)
            } catch (_: Exception) {}
        }
    }

    fun returnToHome(homeX: Float, homeY: Float) {
        mainHandler.post {
            if (!isAttached || cursorView == null) return@post
            val curX = layoutParams.x.toFloat()
            val curY = layoutParams.y.toFloat()
            layoutParams.x = (curX + (homeX - curX) * 0.2f).toInt()
            layoutParams.y = (curY + (homeY - curY) * 0.2f).toInt()
            cursorView?.setState(VisualCursorState.NORMAL)
            try {
                windowManager.updateViewLayout(cursorView, layoutParams)
            } catch (_: Exception) {}
        }
    }

    fun updateState(state: VisualCursorState) {
        mainHandler.post {
            try {
                cursorView?.setState(state)
            } catch (_: Exception) {}
        }
    }

    fun hide() {
        mainHandler.post {
            if (isAttached && cursorView != null) {
                try {
                    windowManager.removeView(cursorView)
                } catch (_: Exception) {}
                cursorView = null
                isAttached = false
            }
        }
    }

    private class CursorView(context: Context) : View(context) {
        private var currentState = VisualCursorState.NORMAL
        private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#4285F4")
        }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            color = Color.WHITE
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            setMeasuredDimension(90, 90)
        }

        fun setState(state: VisualCursorState) {
            this.currentState = state
            when (state) {
                VisualCursorState.NORMAL -> outerPaint.color = Color.parseColor("#4285F4")
                VisualCursorState.PINCHED -> outerPaint.color = Color.parseColor("#EA4335")
                VisualCursorState.SCROLLING -> outerPaint.color = Color.parseColor("#34A853")
                else -> outerPaint.color = Color.parseColor("#FBBC04")
            }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val radius = if (currentState == VisualCursorState.PINCHED) 28f else 22f
            canvas.drawCircle(cx, cy, radius, outerPaint)
            canvas.drawCircle(cx, cy, radius, ringPaint)
        }
    }
}