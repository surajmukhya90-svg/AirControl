package com.aircontrol.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.aircontrol.app.ui.screens.DashboardScreen
import com.aircontrol.app.ui.screens.PrivacyScreen

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        setContent {
            MaterialTheme {
                val state by viewModel.uiState.collectAsState()
                var showPrivacy by remember { mutableStateOf(false) }

                if (showPrivacy) {
                    PrivacyScreen(onBack = { showPrivacy = false })
                } else {
                    DashboardScreen(
                        state = state,
                        onToggleTracking = { viewModel.toggleTracking(it) },
                        onSensitivityChange = { viewModel.updateSensitivity(it) },
                        onSmoothingChange = { viewModel.updateSmoothing(it) },
                        onOpenPrivacy = { showPrivacy = true }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStatus()
    }
}