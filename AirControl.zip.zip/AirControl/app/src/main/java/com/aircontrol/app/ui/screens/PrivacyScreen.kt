package com.aircontrol.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Privacy & Safety Guarantee", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            "1. 100% Local On-Device Processing\n" +
            "Your camera frames are processed directly on your smartphone inside the RAM using Google MediaPipe Tasks Vision. Not a single photo, video, or frame is ever saved to storage or uploaded over the internet.\n\n" +
            "2. No Cloud or Hidden Server Transmission\n" +
            "The app functions completely offline without requiring any network permissions or accounts.\n\n" +
            "3. Legitimate Accessibility Usage\n" +
            "Android's AccessibilityService is strictly used to inject touch events (taps, drags, scrolls) initiated by your hand movements. The app does not read passwords, text messages, or screen content.\n\n" +
            "4. Immediate Termination\n" +
            "The moment you toggle AirControl OFF, the camera pipeline and overlay are destroyed immediately.",
            fontSize = 14.sp,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Dashboard")
        }
    }
}