package com.aircontrol.app.domain

import kotlin.math.hypot

class GestureStateMachine(
    private val pinchThreshold: Float = 0.045f,
    private val longPressDelayMs: Long = 600L
) {
    private var pinchStartTime = 0L
    private var isPinching = false
    private var isLongPressDispatched = false
    private var lastClickTime = 0L
    private val clickCooldownMs = 300L

    fun processFrame(
        thumbTipX: Float, thumbTipY: Float,
        indexTipX: Float, indexTipY: Float,
        middleTipY: Float,
        screenX: Float, screenY: Float,
        currentTimeMs: Long,
        onAction: (GestureAction) -> Unit,
        onStateChange: (VisualCursorState) -> Unit
    ) {
        val pinchDistance = hypot((thumbTipX - indexTipX).toDouble(), (thumbTipY - indexTipY).toDouble()).toFloat()

        if (pinchDistance < pinchThreshold) {
            if (!isPinching) {
                isPinching = true
                pinchStartTime = currentTimeMs
                isLongPressDispatched = false
                onStateChange(VisualCursorState.PINCHED)
            } else {
                val duration = currentTimeMs - pinchStartTime
                if (duration >= longPressDelayMs && !isLongPressDispatched) {
                    isLongPressDispatched = true
                    onStateChange(VisualCursorState.LONG_PRESS)
                    onAction(GestureAction.LongPress(screenX, screenY))
                }
            }
        } else {
            if (isPinching) {
                val duration = currentTimeMs - pinchStartTime
                if (!isLongPressDispatched && duration < longPressDelayMs) {
                    if (currentTimeMs - lastClickTime > clickCooldownMs) {
                        lastClickTime = currentTimeMs
                        onAction(GestureAction.Click(screenX, screenY))
                    }
                }
                isPinching = false
                isLongPressDispatched = false
            }
            onStateChange(VisualCursorState.NORMAL)
            onAction(GestureAction.Move(screenX, screenY))
        }
    }

    fun reset() {
        isPinching = false
        isLongPressDispatched = false
        pinchStartTime = 0L
    }
}