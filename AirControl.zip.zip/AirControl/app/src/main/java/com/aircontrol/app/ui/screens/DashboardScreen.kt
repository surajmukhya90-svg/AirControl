package com.aircontrol.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aircontrol.app.ui.AppUiState

@Composable
fun DashboardScreen(
    state: AppUiState,
    onToggleTracking: (Boolean) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onSmoothingChange: (Float) -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AirControl",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Hands-free Air Mouse Control",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Required Permissions", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(10.dp))

                PermissionRow(
                    name = "Accessibility Touch Engine",
                    isGranted = state.isAccessibilityEnabled,
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                PermissionRow(
                    name = "Floating Overlay Permission",
                    isGranted = state.isOverlayPermissionGranted,
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (state.isTrackingRunning) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (state.isTrackingRunning) "Air Control ACTIVE" else "Air Control OFF",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (state.isTrackingRunning) "Pinch finger to tap, move to scroll" else "Switch on to activate air mouse",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = state.isTrackingRunning,
                    enabled = state.isAccessibilityEnabled && state.isOverlayPermissionGranted,
                    onCheckedChange = { onToggleTracking(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Cursor Sensitivity: ${String.format("%.1f", state.settings.sensitivity)}x",
            fontWeight = FontWeight.Medium,
            modifier = Modifier.fillMaxWidth()
        )
        Slider(
            value = state.settings.sensitivity,
            onValueChange = onSensitivityChange,
            valueRange = 0.5f..3.5f
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            "Jitter Smoothing: ${String.format("%.1f", state.settings.smoothing * 100)}%",
            fontWeight = FontWeight.Medium,
            modifier = Modifier.fillMaxWidth()
        )
        Slider(
            value = state.settings.smoothing,
            onValueChange = onSmoothingChange,
            valueRange = 0.1f..0.9f
        )

        Spacer(modifier = Modifier.weight(1f))

        TextButton(onClick = onOpenPrivacy) {
            Text("Privacy & Security Architecture")
        }
    }
}

@Composable
fun PermissionRow(name: String, isGranted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (isGranted) Color(0xFF34A853) else Color(0xFFEA4335)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(name, fontSize = 14.sp)
        }
        if (!isGranted) {
            OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                Text("Fix", fontSize = 12.sp)
            }
        }
    }
}