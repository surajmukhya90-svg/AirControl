package com.aircontrol.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AirAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AirAccessibilityService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { instance = null }
    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun performTap(x: Float, y: Float) {
        val clickPath = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(clickPath, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun performReelNext(width: Float, height: Float) {
        val path = Path().apply {
            moveTo(width / 2f, height * 0.78f)
            lineTo(width / 2f, height * 0.22f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 220))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun performReelPrev(width: Float, height: Float) {
        val path = Path().apply {
            moveTo(width / 2f, height * 0.22f)
            lineTo(width / 2f, height * 0.78f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 220))
            .build()
        dispatchGesture(gesture, null, null)
    }
}