package com.aircontrol.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class AirControlApp : Application() {
    companion object {
        const val CHANNEL_ID = "aircontrol_service_channel"
        lateinit var instance: AirControlApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AirControl Tracking Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies when AirControl is actively tracking your hand."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}